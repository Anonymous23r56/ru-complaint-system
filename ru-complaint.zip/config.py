import os

class Config:
    SECRET_KEY = 'yoursecretkey'
    UPLOAD_FOLDER = 'static/uploads'

    # Email config (Gmail SMTP)
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
    MAIL_USERNAME = 'samuelolokor228@gmail.com'  # Replace with your Gmail
    MAIL_PASSWORD = 'ruuf obmt fqwr xidn'      # Replace with your App Password
    
